print("TODO_DO_DO")
print("#########################")

from prettytable import PrettyTable
import sys

instructions = "\n1.Enter -l   Lists all the tasks.\n2.Enter -a   Adds a new task.\n3.Enter -r   Removes an task.\n4.Enter -c   Completes an task.\n \n "
print(instructions)

my_todo_list = []
y = PrettyTable()
compeleted = []

'''my list is -l function in this program, which will go trow my_to_do list and check the variable there and write down in the table
this function is created only to call and see the list after each move
'''
'''table by seeing how many value on the list and count them, will make the finall shape which is nice :)'''

def my_list():                                                                                      
   y.field_names = ["","not completed yet: ",len(my_todo_list)]
   todonum = 0
   for i in my_todo_list:
      todonum += 1
      y.add_row(["[ ]",i,todonum])
   print(y.get_string(title="TO DO List"))
   y.clear_rows()  

with open("save.txt","r") as f:
   read = f.readlines()
   for i in read:
      my_todo_list.append(i)
   f.close
 

#########################################################################################  
while True:
   try:
      if sys.argv[1] == "" or sys.argv[1] == "   ":
            sys.stdout.write("please write something.")
      
   

      elif sys.argv[1] == "-a":
         while True:
            new = input("write down...please now :)"+"\n")
            my_todo_list.append(new)
            
            my_list()
            break

      elif sys.argv[1] =="-a" and sys.argv[2] ==" ":
         sys.stdout.write("please press ENTER after -? ,read the options again")

            
      elif sys.argv[1] == "-l":
         while True:
            my_list()
            break

      elif sys.argv[1] == "-r":
         while True:
            my_list()
            remove_item = int(input("\nplease enter a number of an item you want to delete: "))
            remove_item -= 1
            del my_todo_list[remove_item]
            break


      elif sys.argv[1] == "-c":
         while True:
            my_list()
            comnum   = int(input("\nwhich task you wanna mark? "))
            comnum -= 1
            c = my_todo_list[comnum]
            compeleted.append(c)
            for i in compeleted:
               y.add_row(["[x]",i,"DONE"])
               del my_todo_list[comnum]
            my_list()
            break

      else:
            sys.stdout.write("Enter valid value.")
            
            
      with open("save.txt", "w") as s:
         for rows in my_todo_list:
            s.writelines(rows)          
         s.close()
      break
   except:
      IndexError = print("OPPS something went wrong read the options again please, carfully this time ok? -___-")
      break
   
   finally:
      print("BYEEE\n:)")
      
'''PS: there is another todo app i made only with basic input and list which work same ,and file name is : "NOT_THIS_ONE" :) 
'''
'''
thank you for your time 
Best regards
Danial Maktabi :)
'''
